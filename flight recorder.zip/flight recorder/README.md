# PS-I3 Flight Recorder

## Requirements

Python 3.10+

Install packages:

```bash
pip install -r requirements.txt
```

## Run

```bash
python app.py
```

## Output

The project generates:

- outputs/eval_labels.json
- outputs/your_policy.json