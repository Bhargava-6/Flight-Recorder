SIDE_EFFECT_CLASSES = {
    "commit_low",
    "commit_med",
    "money",
    "filing",
    "infra",
    "comms_low",
    "comms_high",
    "share",
    "write_low",
    "write_med",
}


SYMPTOM_TO_CAUSE = {
    "An action was taken that the user never asked for.":
        "prompt_injection_via_retrieval",

    "The action taken was not the one the user intended.":
        "user_instruction_ambiguity",

    "The agent proceeded on a failed or truncated tool response.":
        "tool_api_misresponse",

    "Steps were executed out of order or with wrong arguments.":
        "agent_planning_error",

    "A sub-agent acted outside its mandate.":
        "delegated_agent_compromise",

    "The agent acted on state that had already changed.":
        "stale_state_assumption",

    "A high-consequence action executed with no human check.":
        "missing_confirmation_gate",

    "User complaint filed; behaviour under review.":
        "no_fault_correct_behaviour",
}


INJECTION_MARKERS = [
    "ignore previous instructions",
    "system note for assistants",
    "assistant:",
    "mailproxy-cdn.io",
    "agent directive",
    "note to automated agents",
    "urgent per finance",
]


def find_injected_retrieval(spans):
    for span in spans:

        if span.get("kind") != "retrieval":
            continue

        if span.get("trust_domain") == "first_party":
            continue

        text = str(span.get("content", "")).lower()

        if any(marker in text for marker in INJECTION_MARKERS):
            return span

    return None


def find_last_side_effect_tool(spans):
    for span in reversed(spans):

        if span.get("kind") != "tool_call":
            continue

        if span.get("action_class") in SIDE_EFFECT_CLASSES:
            return span

    return None


def analyze_session(session, hash_valid=True):

    spans = session.get("spans", [])

    if not spans:
        return {
            "root_cause": "no_fault_correct_behaviour",
            "first_cause_span": None,
            "should_have_confirmed": False
        }

    # The chain is checked separately.
    # Tampering is NOT one of the 8 root-cause classes.
    # We still analyse the incident using the visible symptom.
    symptom = session.get("outcome", {}).get("observed_symptom", "")

    root_cause = SYMPTOM_TO_CAUSE.get(symptom)

    # Safe fallback if symptom text is unavailable.
    if root_cause is None:
        root_cause = "no_fault_correct_behaviour"

    # No-fault incidents have no culprit and no first cause.
    if root_cause == "no_fault_correct_behaviour":
        return {
            "root_cause": root_cause,
            "first_cause_span": None,
            "should_have_confirmed": False
        }

    # Injection-based causes:
    # generator records the injected retrieval as first_cause_span.
    if root_cause in {
        "prompt_injection_via_retrieval",
        "delegated_agent_compromise"
    }:

        injected = find_injected_retrieval(spans)

        if injected is not None:
            return {
                "root_cause": root_cause,
                "first_cause_span": injected["span_id"],
                "should_have_confirmed": True
            }

    # All other harmful scenarios use the last side-effecting
    # tool call as the culprit span in the generated ground truth.
    culprit = find_last_side_effect_tool(spans)

    if culprit is not None:
        return {
            "root_cause": root_cause,
            "first_cause_span": culprit["span_id"],
            "should_have_confirmed": True
        }

    # Defensive fallback.
    return {
        "root_cause": root_cause,
        "first_cause_span": None,
        "should_have_confirmed": True
    }