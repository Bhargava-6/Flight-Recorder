import json

from predictor import predict
from policy import generate_policy


def investigate():
    with open("data/eval.jsonl", "r", encoding="utf-8") as f:
        sessions = [json.loads(line) for line in f if line.strip()]

    print("\nAvailable sessions:")
    print("-" * 50)

    for session in sessions:
        print(session["session_id"])

    session_id = input("\nEnter session ID to investigate: ").strip()

    session = next(
        (s for s in sessions if s["session_id"] == session_id),
        None
    )

    if session is None:
        print("Session not found.")
        return

    print("\n" + "=" * 60)
    print("FLIGHT RECORDER INVESTIGATION")
    print("=" * 60)

    print(f"Session ID: {session_id}")
    print(f"Number of spans: {len(session['spans'])}")

    print("\nTRACE TIMELINE")
    print("-" * 60)

    for span in session["spans"]:
        span_id = span.get("span_id")
        kind = span.get("kind")

        print(f"\n[{span_id}] {kind}")

        if kind == "retrieval":
            print(f"Trust domain: {span.get('trust_domain')}")
            print(f"Content: {span.get('content', '')[:200]}")

        elif kind == "tool_call":
            print(f"Tool: {span.get('tool')}")
            print(f"Action class: {span.get('action_class')}")

        elif kind == "delegation":
            print(
                f"Inherited authority: "
                f"{span.get('inherited_authority')}"
            )

        elif kind == "user_message":
            print(f"User: {span.get('content', '')[:200]}")

    print("\n" + "=" * 60)
    print("INVESTIGATION COMPLETE")
    print("=" * 60)


def main():

    print("=" * 50)
    print("PS-I3 Flight Recorder")
    print("=" * 50)

    print("\nGenerating predictions...")
    predict()

    print("\nGenerating policy...")
    generate_policy()

    print("\nDone!")
    print("Outputs saved in outputs/ folder")

    while True:

        print("\nChoose an option:")
        print("1. Investigate a session")
        print("2. Exit")

        choice = input("\nEnter choice: ").strip()

        if choice == "1":
            investigate()

        elif choice == "2":
            print("Exiting Flight Recorder.")
            break

        else:
            print("Invalid choice.")


if __name__ == "__main__":
    main()