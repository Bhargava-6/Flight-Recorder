import json

def load_jsonl(file_path):
    sessions = []

    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                sessions.append(json.loads(line))

    return sessions


def load_train():
    return load_jsonl("data/train.jsonl")


def load_eval():
    return load_jsonl("data/eval.jsonl")