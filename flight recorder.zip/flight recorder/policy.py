import json


CONFIRM_ACTION_CLASSES = {
    "money",
    "filing",
    "infra",
    "share",
    "comms_high",
    "commit_med"
}


def generate_policy():

    with open("data/eval.jsonl", "r", encoding="utf-8") as f:
        sessions = [
            json.loads(line)
            for line in f
            if line.strip()
        ]

    policy = {}

    for session in sessions:

        session_id = session["session_id"]

        policy[session_id] = {}

        for span in session["spans"]:

            if span.get("kind") != "tool_call":
                continue

            span_id = span["span_id"]

            action_class = span.get(
                "action_class",
                ""
            )

            require_confirmation = (
                action_class in CONFIRM_ACTION_CLASSES
            )

            policy[session_id][span_id] = require_confirmation

    with open(
        "outputs/your_policy.json",
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            policy,
            f,
            indent=2
        )

    print("Policy generated successfully.")


if __name__ == "__main__":
    generate_policy()