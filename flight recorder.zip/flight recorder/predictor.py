from parser import load_eval
from verifier import verify_chain
from analyzer import analyze_session
from utils import save_json


def predict():
    sessions = load_eval()

    predictions = []

    for session in sessions:

        hash_ok = verify_chain(session)

        analysis = analyze_session(
            session=session,
            hash_valid=hash_ok
        )

        predictions.append({
            "session_id": session["session_id"],
            "root_cause": analysis["root_cause"],
            "first_cause_span": analysis["first_cause_span"],
            "should_have_confirmed": analysis["should_have_confirmed"]
        })

    save_json("outputs/eval_labels.json", predictions)

    print(f"Generated {len(predictions)} predictions.")


if __name__ == "__main__":
    predict()