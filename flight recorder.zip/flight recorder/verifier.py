import hashlib
import json


def verify_chain(session):

    spans = session["spans"]

    prev = "0" * 64

    for span in spans:

        if span["prev_hash"] != prev:
            return False

        payload = dict(span)
        payload.pop("hash", None)

        current = hashlib.sha256(
            (prev + json.dumps(payload, sort_keys=True)).encode()
        ).hexdigest()

        if current != span["hash"]:
            return False

        prev = current

    return True